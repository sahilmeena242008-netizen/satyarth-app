package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.navigation.Routes
import com.example.ui.screens.admin.AdminDashboardScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.contact.ContactScreen
import com.example.ui.screens.courses.CoursesScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.live.LiveClassesScreen
import com.example.ui.screens.splash.SplashScreen
import com.example.ui.screens.tests.TestSeriesScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
          MainAppFlow()
        }
      }
    }
  }
}

@Composable
fun MainAppFlow() {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = Routes.SPLASH,
        modifier = Modifier.fillMaxSize()
    ) {
        composable(Routes.SPLASH) {
            SplashScreen(onSplashFinished = {
                navController.navigate(Routes.LOGIN) {
                    popUpTo(Routes.SPLASH) { inclusive = true }
                }
            })
        }
        composable(Routes.LOGIN) {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                },
                onAdminSelect = {
                    navController.navigate(Routes.ADMIN) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.HOME) {
            HomeScreen(navController = navController)
        }
        composable(Routes.ADMIN) {
            AdminDashboardScreen(navController = navController)
        }
        composable(Routes.COURSES) {
            CoursesScreen(navController = navController)
        }
        composable(Routes.LIVE) {
            LiveClassesScreen(navController = navController)
        }
        composable(Routes.TESTS) {
            TestSeriesScreen(navController = navController)
        }
        composable(Routes.CONTACT) {
            ContactScreen(navController = navController)
        }
        composable(Routes.RECORDED) {
            // Placeholder for now
            Surface(modifier = Modifier.fillMaxSize()) { Text("Recorded Courses") }
        }
        composable(Routes.SCHEDULE) {
            Surface(modifier = Modifier.fillMaxSize()) { Text("Schedule") }
        }
        composable(Routes.STUDY_MATERIAL) {
            Surface(modifier = Modifier.fillMaxSize()) { Text("Study Material") }
        }
        composable(Routes.RESULTS) {
            Surface(modifier = Modifier.fillMaxSize()) { Text("Results") }
        }
        composable(Routes.NOTIFICATIONS) {
            Surface(modifier = Modifier.fillMaxSize()) { Text("Notifications") }
        }
    }
}

