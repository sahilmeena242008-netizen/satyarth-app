package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF1565C0)
val BlueDark = Color(0xFF0D47A1)
val BlueLight = Color(0xFF64B5F6)

val OrangeSecondary = Color(0xFFFF8F00)
val OrangeDark = Color(0xFFE65100)
val OrangeLight = Color(0xFFFFB300)

val BackgroundLight = Color(0xFFF8F9FA)
val SurfaceLight = Color(0xFFFFFFFF)

val BackgroundDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
