package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CastForEducation
import androidx.compose.material.icons.filled.ContactSupport
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.ui.graphics.vector.ImageVector

object Routes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val HOME = "home"
    const val COURSES = "courses"
    const val LIVE = "live"
    const val RECORDED = "recorded"
    const val SCHEDULE = "schedule"
    const val TESTS = "tests"
    const val STUDY_MATERIAL = "study_material"
    const val RESULTS = "results"
    const val NOTIFICATIONS = "notifications"
    const val CONTACT = "contact"
    const val ADMIN = "admin"
}

data class DrawerItem(
    val title: String,
    val route: String,
    val icon: ImageVector
)

val MainDrawerItems = listOf(
    DrawerItem("Dashboard", Routes.HOME, Icons.Default.Dashboard),
    DrawerItem("Live Classes", Routes.LIVE, Icons.Default.CastForEducation),
    DrawerItem("Recorded Courses", Routes.RECORDED, Icons.Default.OndemandVideo),
    DrawerItem("Test Series", Routes.TESTS, Icons.Default.Quiz),
    DrawerItem("Study Material", Routes.STUDY_MATERIAL, Icons.Default.MenuBook),
    DrawerItem("Results", Routes.RESULTS, Icons.Default.EmojiEvents),
    DrawerItem("Live Schedule", Routes.SCHEDULE, Icons.Default.Schedule),
    DrawerItem("Notifications", Routes.NOTIFICATIONS, Icons.Default.Notifications),
    DrawerItem("Contact Us", Routes.CONTACT, Icons.Default.ContactSupport),
)
